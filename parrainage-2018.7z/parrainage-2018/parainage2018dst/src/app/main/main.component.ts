import {Component, AfterViewInit, OnInit} from '@angular/core';
import { Socket } from 'ngx-socket-io';
import {Observable} from 'rxjs';
import {DataService} from '../data.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit, AfterViewInit {

  title = 'app';
  cliked= false;
  zoom = false;
  tof2;
  tof3;
  tof4;
  finAnime1 = true;
  finAnime2 = false;
  showFinalImage1= false;
  showFinalImage2= false;
  round2 = false;
  automatique = false;
  /*
  selected= {
    urlPhoto : "",
    responsable: "",
    nom:"",
    telephone:""
  };
  */
  selected= {
    prenom: '',
    nom: '',
    numero: '',
    formation: '',
    niveau: 0,
    photo: '',
    id: '',
  };

  formation="";
/*  selected1= {
    urlPhoto : "",
    responsable: "",
    nom:"",
    telephone:""
  };
 */
selected1= {
  prenom: '',
  nom: '',
  numero: '',
  formation: '',
  niveau: 0,
  photo: '',
  id: ''
};
/*
selected2= {
    urlPhoto : "",
    responsable: "",
    nom:"",
    telephone:""
  };
*/
selected2= {
    prenom: '',
    nom: '',
    numero: '',
    formation: '',
    niveau: 0,
    photo: '',
    id: ''
  };

  familles= [];
  fin = false;
  ngAfterViewInit(){

  }

  constructor(private dataService: DataService, private socket: Socket) {
    this.getMessage().subscribe(
      data => {
        console.log(data);
        this.clickTheClick();
        console.log(data);
        if (data == 'start'){
          this.clickTheClick();
        }
      },
      error => console.log(error)
    );

    document.addEventListener('keyup', (e) => {
      if (e.key == '7'){
        this.sendMessage('restart');
        if (this.fin == true){
          this.fin = false;
          this.reinitialiser();
        }
      }
      if (e.key == '1'){
        this.automatique=true;
        if (this.fin == true){
          this.fin = false;
          this.reinitialiser();
        }
        this.clickTheClick();
      }
    });
  }


  sendMessage(msg: string) {
    this.socket.emit('message', msg);
  }

  getMessage() {
    return this.socket.fromEvent('message')
      .map(data => data['msg']);
  }


  ngOnInit() {
  }
  
  jumeller(filleulId, parrainId){
    this.dataService.patch('Filleuls/' + filleulId, {parrainId: parrainId, actif: "false"})
      .subscribe(
        (data: any) => {
          this.dataService.patch('Parrains/' + parrainId, {actif: "false"})
            .subscribe(
              (data: any) => {
                console.log(data);
                if(this.automatique){
                  this.fin = true;
                  this.sendMessage('restart');
                  setTimeout(() => {
                    if (this.fin == true){
                      this.fin = false;
                      this.reinitialiser();
                    }
                  }, 3000);

                  setTimeout(() => {
                    this.clickTheClick();
                  }, 5000);
                  
                }
              },
              err => {
                console.log(err);

              }
            );
        },
        err => {
          console.log(err);
        }
      );
  }

  clickTheClick(){
    if (this.cliked == false){
      this.cliked = true;
      if (this.round2 == false){
        this.findOne('first', 'Filleuls');
        const data = {
          id: this.selected.id,
          prenom: this.selected.prenom,
          nom: this.selected.nom,
          numero: this.selected.numero,
          photo: this.selected.photo,
          niveau: this.selected.niveau
        };
        setTimeout(() => {
          this.finAnime1 = false;
          this.selected['type'] = 'photo';
          this.sendMessage(JSON.stringify(this.selected));
          console.log("selected = "+JSON.stringify(this.selected));
        }, 15000);

        setTimeout(() => {
          this.showFinalImage1 = true;
          this.finAnime2 = true;
          this.cliked = false;
          this.round2 = true;
          if(this.automatique==true){
            this.sendMessage('restart');
            if (this.fin == true){
              this.fin = false;
              this.reinitialiser();
            }
          }
        }, 20000);

        if(this.automatique==true){
          setTimeout(() => {
            this.clickTheClick();
          }, 22000);
        }

      }
      else{
        this.findOne('second', 'Parrains');
        setTimeout(() => {
          this.finAnime2 = false;
          this.selected['type'] = 'photo';
          this.sendMessage(JSON.stringify(this.selected));
        }, 15000);

        setTimeout(() => {
          this.showFinalImage2 = true;
          this.zoom = true;
          this.fin = true;
          this.jumeller(this.selected1['id'], this.selected2['id']);
        }, 20000);

      }
    }
  }

  findOne(myRound, etudiants){
    if(myRound=="first"){
      this.dataService.get(etudiants + '?filter=' + encodeURIComponent('{"where":{"actif":"true"}}'))
      .subscribe(
        (familles: any) => {;
          if (familles.length > 0){
            this.familles = familles;
            const index = Math.floor(Math.random() * familles.length);
            this.selected = familles[index];
            if(myRound=="first"){
              this.formation = familles[index].formation;
            }
            let index2;
            let index3;
            let index4;
            if (familles.length > 1) {
              do {
                index2 = Math.floor(Math.random() * familles.length);
              }
              while (index2 == index);
              this.tof3 = familles[index2];
            }
            if (familles.length > 2) {
              do{
                index3 = Math.floor(Math.random() * familles.length);
              }
              while (index3 == index || index3 == index2);
              this.tof2 = familles[index3];
            }
            if (familles.length > 3) {
              do {
                index4 = Math.floor(Math.random() * familles.length);
              }
              while (index4 == index || index4 == index2 || index4 == index3);
              this.tof4 = familles[index4];
            }
            if (myRound == 'first'){
              this.selected1 = this.selected;
            }
            else{
              this.selected2 = this.selected;
              console.log("selected2",this.selected2);
              console.log("selected1",this.selected1);
            }
          }
          else{
            if (etudiants == 'Parrains'){
              this.dataService.post('Parrains/update?filter={"where":{}}', {actif: "true"})
                .subscribe(
                  (parrains: any) => {
                    console.log("on selectionne un parrain");
                    this.findOne('Second', 'Parrains');
                  },
                  err => {
                    console.log(err);
                  }
                );
            }
            else{
              alert('Parrainage bouclé !');
            }
        }
      });
    }
    else{
      this.dataService.get(etudiants + '?filter=' + encodeURIComponent('{"where":{"actif":"true","formation":"'+ this.formation +'"}}'))
      .subscribe(
        (familles: any) => {;
          if (familles.length > 0){
            this.familles = familles;
            const index = Math.floor(Math.random() * familles.length);
            this.selected = familles[index];
            let index2;
            let index3;
            let index4;
            if (familles.length > 1) {
              do {
                index2 = Math.floor(Math.random() * familles.length);
              }
              while (index2 == index);
              this.tof3 = familles[index2];
            }
            if (familles.length > 2) {
              do{
                index3 = Math.floor(Math.random() * familles.length);
              }
              while (index3 == index || index3 == index2);
              this.tof2 = familles[index3];
            }
            if (familles.length > 3) {
              do {
                index4 = Math.floor(Math.random() * familles.length);
              }
              while (index4 == index || index4 == index2 || index4 == index3);
              this.tof4 = familles[index4];
            }
            if (myRound == 'first'){
              this.selected1 = this.selected;
            }
            else{
              this.selected2 = this.selected;
              console.log("selected2",this.selected2);
              console.log("selected1",this.selected1);
            }
          }
          else{
            if (etudiants == 'Parrains'){
              this.dataService.post('Parrains/update?filter={"where":{"formation":"'+this.formation+'"}}', {actif: "true"})
                .subscribe(
                  (parrains: any) => {
                    console.log("on selectionne un parrain");
                    this.findOne('Second', 'Parrains');
                  },
                  err => {
                    console.log(err);
                  }
                );
            }
            else{
              alert('Parrainage bouclé !');
            }
        }
      });
    }
  }

  reinitialiser(){
    this.cliked = false;
    this.zoom = false;
    this.tof2 = null;
    this.tof3 = null;
    this.tof4 = null;
    this.finAnime1 = true;
    this.finAnime2 = false;
    this.showFinalImage1 = false;
    this.showFinalImage2 = false;
    this.round2 = false;
    this.selected = {
      prenom: '',
      nom: '',
      numero: '',
      formation: '',
      niveau: 0,
      photo: '',
      id: ''
    };
    this.selected1 = {
      prenom: '',
      nom: '',
      numero: '',
      formation: '',
      niveau: 0,
      photo: '',
      id: '',

    };

    this.selected2 = {
      prenom: '',
      nom: '',
      numero: '',
      formation: '',
      niveau: 0,
      photo: '',
      id: ''
    };
    this.familles = [];
  }
}
