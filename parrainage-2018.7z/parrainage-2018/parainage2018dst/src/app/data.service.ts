
import { Injectable } from '@angular/core';
import {Http} from "@angular/http";


@Injectable()
export class DataService {

  constructor(private http: Http) { }

 //baseUrl = "https://jumelage-takussanu-api.herokuapp.com/api/";
  // baseUrl = 'https://parrainage2018-2019.herokuapp.com/api/';
 baseUrl = "http://localhost:3000/api/";
  get(url) {
    return this.http.get(this.baseUrl + url).map(res => res.json());
  }

  delete(url, id){
    return this.http.delete(this.baseUrl + url + "/" + id).map(res=> res.json())
  }

  post(url, data){
    return this.http.post(this.baseUrl + url, data).map(res=> res.json())
  }

  patch(url, data){
    return this.http.patch(this.baseUrl + url, data).map(res=> res.json())
  }

}
