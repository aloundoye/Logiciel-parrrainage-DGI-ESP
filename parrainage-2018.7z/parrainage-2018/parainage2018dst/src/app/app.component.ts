import {Component, AfterViewInit} from '@angular/core';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit{
  title = 'app';
  cliked= false;
  finAnime1 = true;
  finAnime2 = false;
  showFinalImage1= false;
  showFinalImage2= false;
  round2 = false;
  ngAfterViewInit(){

  }

  clickTheClick(){
    this.cliked = true;
    if (this.round2 == false){
      Observable.interval(2000)
        .subscribe(i => {
          this.finAnime1 = false;
        });
      Observable.interval(7000)
        .subscribe(i => {
          this.showFinalImage1 = true;
          this.finAnime2 = true;
          this.cliked = false;
          this.round2 = true;
        });
    }
    else{
      Observable.interval(2000)
        .subscribe(i => {
          this.finAnime2 = false;
        });
      Observable.interval(7000)
        .subscribe(i => {
          this.showFinalImage2 = true;
          //this.cliked=false;
        });
      Observable.interval(11000)
        .subscribe(i => {

        });
    }
  }

}
