import {Routes, RouterModule} from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
import { AppComponent } from './app.component';
import { BuzzerComponent } from './buzzer/buzzer.component';
import { MainComponent } from './main/main.component';
import {DataService} from './data.service';
import {HttpModule} from '@angular/http';
//import {Ng4LoadingSpinnerModule} from 'ng4-loading-spinner';

const appRoutes: Routes = [
  { path: '', component: MainComponent },
  { path: 'buzzer', component: BuzzerComponent }
];

var api = 'http://jumelage-takussanu-api.herokuapp.com/';

const config: SocketIoConfig = { url: api, options: {} };


@NgModule({
  declarations: [
    AppComponent,
    BuzzerComponent,
    MainComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    //Ng4LoadingSpinnerModule.forRoot(),
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
    SocketIoModule.forRoot(config)
  ],
  providers: [
    DataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
