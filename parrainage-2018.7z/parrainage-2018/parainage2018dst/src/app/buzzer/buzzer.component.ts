import 'rxjs/add/operator/map';
import { Component, OnInit } from '@angular/core';
import { Socket } from 'ngx-socket-io';
//import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';

@Component({
  selector: 'app-buzzer',
  templateUrl: './buzzer.component.html',
  styleUrls: ['./buzzer.component.css']
})
export class BuzzerComponent implements OnInit {

  activeBuzzer: Boolean = true;
  spinner = false;
  selected;
  constructor(private socket: Socket/*, private spinnerService: Ng4LoadingSpinnerService*/) {
    this.getMessage().subscribe(
      data => {
        if (data == 'restart') {
          //this.spinnerService.hide();
          this.spinner = false;
          this.selected = null;
          this.activeBuzzer = true;
        }
        else if (JSON.parse(data)['type'] == 'photo'){
          this.selected = JSON.parse(data);
          this.spinner = false;
          //this.spinnerService.hide();
        }
      },
      error => console.log(error)
    );
  }

  template = `<img class="custom-spinner-template stage" src="https://loading.io/spinners/microsoft/lg.rotating-balls-spinner.gif">`;

  sendMessage(msg: string) {
    console.log(msg);
    this.socket.emit('message', msg);
    console.log('clicked button buzzer');
    this.spinner = true;
    //this.spinnerService.show();
  }

  getMessage() {
    return this.socket.fromEvent('message')
      .map(data => data['msg']);
  }

  ngOnInit() {

  }

    clickEventHandler() {
    this.activeBuzzer = false;
    this.sendMessage('start');
  }
}
