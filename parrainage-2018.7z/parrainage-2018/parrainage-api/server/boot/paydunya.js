
module.exports = function(app) {

    var paydunya = require('paydunya');
    var bodyParser = require('body-parser');
    // parse application/json
    app.use(bodyParser.json())

    var setup = new paydunya.Setup({
        masterKey: '0uu4c7Pc-mFhE-CmrI-vhnP-Epnay1VwAwHG',
        privateKey: 'live_private_ArJ1ZH9zco0bq1GPsUESaxEP5zv',
        publicKey: 'live_public_cGr2ZUNE6Nlda7nQMYSxxv3qgBN',
        token: 'wbBjZuZXo9t104RCtoxg',
        mode: 'prod'
      });

      var store = new paydunya.Store({
        name: 'Integration ESP/DST 2018-2019', // only name is required
        phoneNumber: '777494817',
        postalAddress: 'UCAD/ESP/DGI/DST',
        cancelURL: 'https://parainage2018-2019.firebaseapp.com/inscription',
        returnURL: 'https://parainage2018-2019.firebaseapp.com/inscription',
        logoURL: 'http://www.dynamicsportstraining.com/wp-content/uploads/2018/03/team-dst.png'
      });

      var invoice = new paydunya.CheckoutInvoice(setup, store);

    app.post("/api/pay",function(req,res){
        var user = req.body;

        invoice.addItem('Payement pour le parrainage', 1, 10000, 10000); // name, quantity, unit price, total price
        invoice.description = "La journée d'integration est faite pour vous, étudiants de première année donc pensez à cotiser si ce n'est pas déjà fait. Nous vous rappelons que vous êtes tenu de vous inscrire avant la journée d'intégration";

        invoice.totalAmount = 10000;

        invoice.create()
        .then(function (){
            invoice.status;
            token = invoice.token; // invoice token
            invoice.responseText;
            console.log(invoice.url); // PAYDUNYA redirect checkout url
            res.send(invoice);
        })
        .catch(function (e) {
            console.log(e);
        });
    })

    app.post("/api/confirm",function(req,res){
        var token = req.body.token;
        invoice.confirm(token)
        .then(function (){
            invoice.status; //  completed, pending, canceled or fail
            invoice.responseText;

            // available if status == 'completed'
            invoice.customer; // {name: 'Alioune Badara', phone: '772639273', email: 'alioune@gmail.com'}
            invoice.receiptURL; // 'https://app.paydunya.com/sandbox-checkout/receipt/pdf/test_44a6fef19a.pdf'
            res.send(invoice);
        })
        .catch(function (e) {
            console.log(e);
        });
    })

}
