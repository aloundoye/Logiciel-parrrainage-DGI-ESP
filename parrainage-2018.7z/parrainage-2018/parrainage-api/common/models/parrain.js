'use strict';

module.exports = function(Parrain) {
    Parrain.beforeRemote("create" , ctx => {
        let user = ctx.args.data;
        if (!user.email){
          user.email = `${user.numero}@telephone.com`;
          user.password="passer";
        }
        return Promise.resolve();
      })
};