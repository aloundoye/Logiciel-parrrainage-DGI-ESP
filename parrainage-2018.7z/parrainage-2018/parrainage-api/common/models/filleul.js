'use strict';
var request = require("request");

var tokenObject = {
  token_type: 'Bearer',
  access_token: 'IchCbv1hlXSDzwTIotpDtNGJL3oL',
  expires_in: '7776000'
};

function sendSMS(access_token, numeroTel, message) {
  var headers = {
    'Authorization': "Bearer " + access_token,
    'Content-Type': 'application/json'
  };
  var body = {
    outboundSMSMessageRequest: {
      address: "tel:+221" + numeroTel,
      senderAddress: "tel:+221771720455",
      outboundSMSTextMessage: {
        message: message
      }
    }
  };
  var options = {
    uri: 'https://api.orange.com/smsmessaging/v1/outbound/tel:+221771720455/requests',
    method: 'POST',
    headers: headers,
    body: JSON.stringify(body)
  };

  request(options, function (error, response, body) {
    console.log(body);
  });
}

module.exports = function(Filleul) {
  Filleul.beforeRemote("create" , ctx => {
    let user = ctx.args.data;
    if (!user.email){
      user.email = `${user.numero}@telephone.com`;
      user.password="passer";
    }
    return Promise.resolve();
  })

  Filleul.afterRemote("prototype.patchAttributes", ctx => {
    let filleul = ctx.instance;
    Filleul.app.models.Parrain.findById(filleul.parrainId)
      .then(
        (data) => {
          console.log('====================================');
          console.log("Data Parrain : ",data);
          console.log('====================================');
          console.log("Filleul : ", filleul);
          sendSMS(tokenObject.access_token, "777494817", `Parrainage DST:\n Mentor: ${data.prenom} ${data.nom}\nTéléphone : ${data.numero} . \nMerci.`);
          sendSMS(tokenObject.access_token, `${data.numero}`, `Parrainage DST:\n Filleul: ${filleul.prenom} ${filleul.nom}\nTéléphone : ${filleul.numero} . \nMerci.`);
        },
        error => {
          console.log('====================================');
          console.log(error);
          console.log('====================================');
        }
      )
    return Promise.resolve();
  })
};
