'use strict';

module.exports = function(Token) {

};
