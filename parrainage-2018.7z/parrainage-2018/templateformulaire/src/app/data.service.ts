import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  baseUrl = "https://parrainage2018-2019.herokuapp.com/api/";
 // baseUrl = "http://localhost:3000/api/";

  constructor(private http : HttpClient) { }

  post(url, data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.baseUrl + url, data)
          .subscribe(res => {
            resolve(res);
          }, (err) => {
            reject(err);
          });
    });
  }

  get(url) {
    return new Promise((resolve, reject) => {
      this.http.get(this.baseUrl + url)
          .subscribe(res => {
            resolve(res);
          }, (err) => {
            reject(err);
          });
    });
  }

  patch(url, data) {
    return new Promise((resolve, reject) => {
      this.http.patch(this.baseUrl + url, data)
          .subscribe(res => {
            resolve(res);
          }, (err) => {
            reject(err);
          });
    });
  }

  delete(url) {
    return new Promise((resolve, reject) => {
      this.http.delete(this.baseUrl + url)
          .subscribe(res => {
            resolve(res);
          }, (err) => {
            reject(err);
          });
    });
  }
}
