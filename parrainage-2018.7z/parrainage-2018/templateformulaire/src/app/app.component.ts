import { Component } from '@angular/core';
import { ElementRef } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/storage';
import { finalize } from 'rxjs/operators';
import { DataService } from 'src/app/data.service';
import { ToasterService } from 'angular2-toaster/src/toaster.service';
import { concat } from 'rxjs/internal/observable/concat';
import { $ } from 'protractor';

declare let swal:any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'parrainage-web';

  file;
  image1=false;
  isSubmitClicked = false;
  changePicture = false;
  showPictures = false;
  isParrain = true;

  load = false;

  user = {
    nom:"",
    prenom:'',
    formation:"DISTTR",
    niveau:1,
    numero:"",
    photo:"",
    payer : false,
    password:"passer"
  }

  token;
  //status;
  constructor(
    private element: ElementRef,
    private storage: AngularFireStorage,
    private dataService : DataService,
    private toasterService : ToasterService){
      var url = window.location.href;
      if(url.includes("?token=")){
        this.token = url.split("?token=")[1];
        this.IsConfirm();
      }
  }

  checkUserPicture(){
    this.image1 = false;
    let telBeginin = this.user.numero.substr(0,2);
    if(this.user.numero!="" && this.user.numero.length==9 && (telBeginin=="77" || telBeginin=="78" || telBeginin=="70" || telBeginin=="76")){
      this.isSubmitClicked = true;
      this.load = true;
      this.dataService.get('Parrains?filter={"where":{"numero":"'+ this.user.numero +'"}}')
        .then(
          (parrain:any)=>{
            if(parrain && parrain[0]){
              this.user = parrain[0];
              this.showPictures = true;
              this.load = false;
              this.isParrain = true;
            }
            else{
              this.dataService.get('Filleuls?filter={"where":{"numero":"'+ this.user.numero +'"}}')
                .then(
                  (filleul:any)=>{
                    if(filleul && filleul[0]){
                      this.user = filleul[0];
                      this.showPictures = true;
                      this.load = false;
                      this.isParrain = false;
                    }
                  }
                )
            }
          }
        )
    }
    else{
      this.popToast("error","Numéro incorect","Veuillez verifié le format du numéro avant de valider");
    }
  }

  validerUserPicture(){
    this.load = true;
    if(!this.image1){
      this.load = false;
      this.popToast("success","Photo changée","Votre photo a été bien changée");
      swal("Photo changée","Votre photo a été bien changée","success");
      this.changePicture = false;
      this.showPictures = false;
      this.reinitialiserUser();
    }
    else{
      this.uploadFile();
    }
  }

  patchUserPicture(){
    if(this.isParrain){
      this.dataService.patch("Parrains/" + this.user['id'],{photo : this.user.photo})
        .then(
          (user:any)=>{
            this.load = false;
            this.popToast("success","Photo changée","Votre photo a été bien changée");
            swal("Photo changée","Votre photo a été bien changée","success");
            this.changePicture = false;
            this.showPictures = false;
            this.reinitialiserUser();
          },
          err=>{
            console.log(err);
          }
        )
    }
    else{
      this.dataService.patch("Filleuls/" + this.user['id'],{photo : this.user.photo})
        .then(
          (user:any)=>{
            this.load = false;
            this.popToast("success","Photo changée","Votre photo a été bien changée");
            swal("Photo changée","Votre photo a été bien changée","success");
            this.changePicture = false;
            this.showPictures = false;
            this.reinitialiserUser();
          },
          err=>{
            console.log(err);
          }
        )
    }
  }

  IsConfirm(){
    console.log(this.token);
  //  console.log(this.status);
    this.dataService.post("confirm",{token:this.token})
      .then(
        (confirm:any)=>{
          console.log(confirm);
          let user = JSON.parse(localStorage.getItem("user"));
          let payer = JSON.parse(localStorage.getItem("payer"));
          if(payer && payer.token == this.token){
            if(confirm.status== "completed"){
              this.dataService.get('Tokens?filter={"where":{"token":"'+this.token+'"}}')
                .then(
                  (tokens:any)=>{
                    if(tokens && tokens.length>0){
                      this.popToast('error',"Erreur","Veuillez suivre la bonne procedure");
                      swal("Erreur", "Veuillez suivre la bonne procedure","error");
                    }
                    else{
                      this.dataService.patch("Filleuls/" + user.id, {payer:true})
                        .then(
                          (filleul:any)=>{
                            console.log(filleul);
                            this.dataService.post("Tokens",{token:this.token})
                              .then(
                                (token:any)=>{
                                  this.popToast("success","Inscription validée","Votre inscription a été bien prise en compte");
                                  swal("Inscription validée!", "Votre inscription a été bien prise en compte!", "success");
                                  document.getElementById("facturePdf")["href"] = payer.receiptURL;
                                  document.getElementById("facturePdf").click();
                                }
                              )
                          }
                        );
                    }
                  }
                )
            }
            else{
              console.log(confirm.status)
              if(confirm.status== "cancelled"){
                this.dataService.delete("Filleuls/"+user.id)
                  .then(
                    (user:any)=>{
                      console.log('User Removed');
                      this.popToast("error","Transaction annulée","Votre inscription est rejetée");
                      swal("Transaction annulée","Votre inscription est rejetée","error");
                    }
                  )
              }
            }
          }
        },
        (err:any)=>{
          console.log(err);
        }
      );
  }

  uploadFile() {
    //const file = this.file; //Il faut le laisser comme ça sans le metre en base 64
    const filePath = '/media/' + new Date().getUTCMilliseconds();
    const fileRef = this.storage.ref(filePath);
    //const task = this.storage.upload(filePath, file);

    const task = this.storage.upload(filePath, this.file);
    task.snapshotChanges().pipe(
        finalize(
            () => fileRef.getDownloadURL()
                .subscribe(
                    url=>{
                        this.user.photo = url;
                        if(this.showPictures){
                          this.patchUserPicture();
                        }
                        else{
                          this.persisteUser();
                        }
                    },
                    err=>{
                    }
                )
        )
    )
    .subscribe(
        (file:any)=>{
            //la il te donne les pourcenntage de l'upload. Tu px ne pas en avoir besoin frere
        },
        err=>{
        }
    )
  }

  updateNiveauFormation(){
    if(document.getElementById("premiere_annee")['checked']){
      this.user.niveau = 1;
    }
    else{
      this.user.niveau = 2;
    }
    if(document.getElementById("dsti")['checked']){
      this.user.formation = "DISTI";
    }
    else{
      this.user.formation = "DISTTR";
    }
  }

  validerForm(){
    console.log(this.user);
    let telBeginin = this.user.numero.substr(0,2);
    if(this.user.nom!=""){
      if(this.user.prenom !=""){
        if(this.image1){
          if(this.user.numero!="" && this.user.numero.length==9 && (telBeginin=="77" || telBeginin=="78" || telBeginin=="70" || telBeginin=="76")){
            this.isSubmitClicked = true;
            this.load = true;
            this.uploadFile();
          }
          else{
            this.popToast("error","Numéro incorect","Veuillez verifié le format du numéro avant de valider");
          }
        }
        else{
          this.popToast("error","Image non renseignée","Veuillez renseigner l'image avant de valider");
        }
      }
      else{
        this.popToast("error","Prenom non renseigné","Veuillez renseigner le prenom avant de validée");
      }
    }
    else{
      this.popToast("error","Nom non renseigné","Veuillez renseigner le nom avant de validée");
    }
  }

  persisteUser(){
    if(this.user.niveau==2){
      this.user.payer = true;
      this.dataService.post("Parrains",this.user)
        .then(
          (user:any)=>{
            this.popToast("success","Ajout avec succes","Votre inscription a été bien validée");
            swal("Inscription validée!", "Votre inscription a été bien prise en compte!", "success");
            this.isSubmitClicked = false;
            this.reinitialiserUser();
          },
          err=>{
            this.isSubmitClicked = false;
           //this.reinitialiserUser();
           if(err.status==422){
              this.popToast("error","Inscription rejetée","Vous vous êtes déja inscrit");
              swal("Inscription rejetée","Vous vous êtes déja inscrit","error");
            }
            else{
              this.popToast("error","Ajout rejeté","Veuillez verifier votre connexion internet et réessayez plutard");
              swal("Ajout rejeté","Veuillez verifier votre connexion internet et réessayez plutard","error");
            }
            this.load = false;
          }
        )
    }
    else{
      this.dataService.post("Filleuls",this.user)
        .then(
          (user:any)=>{
            this.user = user;
            this.payer();
          },
          err=>{
            if(err.status==422){
              this.dataService.get('Filleuls?filter={"where":{"numero":"'+ this.user.numero +'"}}')
                .then(
                  (filleuls:any)=>{
                    if(filleuls && filleuls[0])
                    {
                      this.user = filleuls[0];
                      if(this.user.payer==false){
                        this.payer();
                      }
                      else{
                        this.popToast("error","Ajout rejeté","Vous etes deja inscrit");
                        swal("Ajout rejeté","Vous etes deja inscrit","error");
                      }
                    }
                  }
                )
            }
            else{
              this.popToast("error","Ajout rejeté","Veuillez verifier votre connexion internet et réessayez plutard");
              swal("Ajout rejeté","Veuillez verifier votre connexion internet et réessayez plutard","error");
            }
            this.isSubmitClicked = false;
            console.log(err.status)
            this.load = false;
            console.log(err);
          }
        )
    }
  }
  
  payer(){
    this.dataService.post("pay",this.user)
      .then(
        (payer:any)=>{
          console.log(payer);
          localStorage.setItem("user",JSON.stringify(this.user));
          localStorage.setItem("payer",JSON.stringify(payer));
          document.getElementById("redirect")["href"]=payer.url;
          document.getElementById("redirect").click();
          this.isSubmitClicked = false;
          this.reinitialiserUser();
        },
        err=>{
          console.log(err);
        }
      )
  }

  reinitialiserUser(){
    this.user = {
      nom:"",
      prenom:'',
      formation:'',
      niveau:0,
      numero:"",
      photo:"",
      payer:false,
      password : "passer"
    }
    this.load = false;
  }

  popToast(type,title,message) {
    this.toasterService.pop(type, title, message);
  }

  changeFile(event)
  {
    this.image1=true;
    var reader = new FileReader();
    var image = this.element.nativeElement.querySelector('.img');

    reader.onload = function(e) {
      var src = e.target["result"];
      image.src = src;
    };
    this.file = event.target.files[0];
    reader.readAsDataURL(event.target.files[0]);
  }

  declangeUplaod(){
    document.getElementById("file1").click();
  }

}
