import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FileUploadModule} from 'primeng/fileupload';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AngularFireModule } from '@angular/fire';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { DataService } from 'src/app/data.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToasterModule, ToasterService} from 'angular2-toaster';
import { RouterModule } from '@angular/router';
import { Routes } from '@angular/router';
import { UiSwitchModule } from 'ngx-toggle-switch';

const config = {
  apiKey: "AIzaSyC_xfQNlZ5pEMxtqeWs7sQkclTpYl4IQj4",
  authDomain: "parainage2018-2019.firebaseapp.com",
  databaseURL: "https://parainage2018-2019.firebaseio.com",
  projectId: "parainage2018-2019",
  storageBucket: "parainage2018-2019.appspot.com",
  messagingSenderId: "896939297079"
};

const appRoutes: Routes = [
  { path: 'inscription', component: AppComponent },
  { path: '',
    redirectTo: '/inscription',
    pathMatch: 'full'
  },
  { path: '**', component: AppComponent }
];


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
    FileUploadModule,
    FormsModule,
    UiSwitchModule,
    BrowserAnimationsModule, 
    ToasterModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    AngularFireModule.initializeApp(config), // imports firebase/app needed for everything
    AngularFireStorageModule // imports firebase/storage only needed for storage features
  ],
  providers: [
    DataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
